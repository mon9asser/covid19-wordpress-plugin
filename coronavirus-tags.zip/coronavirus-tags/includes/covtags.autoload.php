<?php



// Error Reporting
error_reporting( E_ALL );
@ini_set( 'display_errors', 'On' );



require_once COVTAGS_DIR . 'includes/callbacks/covtags.vars.php';
require_once COVTAGS_DIR . 'includes/callbacks/covtags.filters.php';
require_once COVTAGS_DIR . 'includes/callbacks/covtags.actions.php';
require_once COVTAGS_DIR . 'includes/classes/covtags.soft.compatibility.php';
require_once COVTAGS_DIR . 'includes/classes/covtags.http.request.php';
require_once COVTAGS_DIR . 'includes/classes/covtags.ui.php';
require_once COVTAGS_DIR . 'includes/classes/shortcodes.php';
require_once COVTAGS_DIR . 'includes/classes/covtags.main.php';
