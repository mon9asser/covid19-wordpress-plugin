(function($){
    "use stirct"
 

})(jQuery);
