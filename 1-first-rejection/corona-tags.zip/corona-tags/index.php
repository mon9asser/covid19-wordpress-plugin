<?php
  get_header();
?>

<div class="container-fluid tags-banner tags-dark">
  <!-- Title -->
  <div class="container text-center tags-title title-container-d">

      <h1 class="covid-title">
        Conrona<span class="colored-item">virus</span> Tags
      </h1>
      <p>
        Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.
      </p>
  </div>

  <!-- Tricker All Countries -->
  <div class="container">
    <?php echo do_shortcode( '[covtags-tricker-world-card dark_mode="yes" field="cases" desc_by="cases"]' ); ?>
  </div>

  <div class="container text-center tags-title">
    <p>
      Customize your own shortcode for <span class="colored-item">COVID 19</span> to be proper with your website
    </p>
  </div>

</div>

<div class="container-fluid tags-white-mode">
  <div class="container">
   <div class="widget-title text-center">
     <h4>
       Datatable with custom fields
     </h4>
     <p class="descr">
       We made unique design contains graph for each country, also many options are provided in shortcode builder
     </p>
   </div>
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <?php echo do_shortcode( '[covtags-all-countries dark_mode="no" graph_type="line" fields="cases,deaths,recovered" icon_flag="yes" paging_type="serials" rows_per_page="7" desc_by="cases"]' ); ?>
      </div>
      <div class="col-sm-12 col-md-6">
        <?php echo do_shortcode( '[covtags-all-countries dark_mode="yes" graph_type="bar" fields="deaths,recovered,cases" field_colors="#ED4C67,green,#FDA7DF" icon_flag="yes" paging_type="serials" rows_per_page="7" desc_by="deaths"]' ); ?>
      </div>
    </div>
 </div>
</div>








<div class="container-fluid tags-white-mode">
  <div class="container">
   <div class="widget-title text-center">
     <h4>
       World Wide Tricker
     </h4>
     <p class="descr">
      Check the top tricker has been descended by total of confirmed cases for each country and the bottom one descended by deaths count, that's mean we are giving you an options in shortcode builder :)
     </p>
   </div>
    <div class="row">
      <div class="col-sm-12 col-md-12">
        <?php echo do_shortcode( '[covtags-tricker-world-card desc_by="deaths" field="deaths" dark_mode="no"]' ); ?>
      </div>
    </div>
 </div>
</div>





<div class="container-fluid tags-white-mode">
  <div class="container">
    <div class="widget-title text-center">
      <h4>
        Covid-19 Cards
      </h4>
      <p class="descr">
        Customize your own Fields as you like, change mode, change options ! our shortcode builder is designed to help you to customize anything related data and next update we will do more :)
      </p>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-statistics dark_mode="yes" style="style-3" layout="flat" fields="cases,deaths,recovered" align_text="center" title="United States" country="usa" icon_flag="yes"]' ); ?>
      </div>
      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-statistics dark_mode="no" style="style-3" title="World Wide In Flat Layout" layout="flat" fields="recovered,cases,deaths"]' ); ?>
      </div>
      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-statistics title="UK" dark_mode="no" style="style-1" layout="flat" fields="cases,deaths,critical" align_text="center" country="UK" icon_flag="yes"]' ); ?>
      </div>
    </div>
 </div>
</div>




<div class="container-fluid tags-white-mode">
  <div class="container">

    <div class="row">
      <div class="col-sm-12 col-md-8">

        <div class="widget-title text-left">
          <h4>
            Covid-19 - World Wide Map
          </h4>
          <p class="descr full-wide">
            Map Card with dark mode
          </p>
        </div>


        <?php echo do_shortcode( '[covtags-map dark_mode="yes"]' ); ?>
      </div>

      <div class="col-sm-12 col-md-4">
        <div class="tags-card-elements">
            <div class="widget-title text-left">
              <h4>
                Status Cards
              </h4>
              <p class="descr full-wide">
                Unique design Card is Showing you calculated mild , critical , recovered and deaths with any graph you selected before !
              </p>
            </div>
            <?php echo do_shortcode( '[covtags-status status_type="active" title="Currently Infected Patients" hide_title="no" show_percentage="yes" use_graph_with="doughnut" icon_flag="yes"]' ); ?>
        </div>

        <div class="tags-card-elements">
            <?php echo do_shortcode( '[covtags-status status_type="active" title="Cases which had an outcome" hide_title="no" show_percentage="yes" dark_mode="yes" use_graph_with="bar" icon_flag="yes"]' ); ?>
        </div>
      </div>
    </div>
 </div>
</div>





<div class="container-fluid tags-white-mode">
  <div class="container">
    <div class="widget-title text-center">
      <h4>
        Customized cards by shortcode
      </h4>
      <p class="descr full-wide">
        --------------------------------------
      </p>
    </div>
    <div class="row">

      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-status status_type="active" country="spain" title="Spain" hide_title="no" show_percentage="yes" dark_mode="no" use_graph_with="polarArea" icon_flag="yes"]' ); ?>
      </div>

      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-status status_type="active" title="United States" country="usa" hide_title="no" show_percentage="yes" dark_mode="yes" use_graph_with="pie" icon_flag="yes"]' ); ?>
      </div>

      <div class="col-sm-12 col-md-4">
        <?php echo do_shortcode( '[covtags-status status_type="active" title="Italy" country="italy" hide_title="no" show_percentage="yes" dark_mode="no" use_graph_with="line" icon_flag="yes"]' ); ?>
      </div>

    </div>

  </div>
</div>

<div class="container-fluid footer-data text-center">
  <div class="container text-center">
    This Demo is installed separately Not included in the plugin
  </div>
  <div class="container text-center">
    Designed by Eratags. Wordpress Development
  </div>
</div>


<?php
  get_footer();
?>
