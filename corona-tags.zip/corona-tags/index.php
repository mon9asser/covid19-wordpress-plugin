<?php
  get_header();
?>



 <div class="banner-covid-tags text-center">
   <div class="tags-wrapper" >
   </div>
    <h1>
      <i class="fas fa-virus"></i>
      <span>Coronavirus</span> Tags
    </h1>
    <p>
      Live Statistics, Cards, Map, Graphs, Trickers, widgets and shortcodes
    </p>
    <p>
      Wordpress plugin
    </p>
 </div>



  <div class="tags-wrapper">
    <div class="row">
      <div class="col-md-8 col-sm-6 col-xs-12">
        <div class="covtags-main-container">
          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>World Wide Tricker</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-tricker-world-card inner-spacing="0 0 5 0" fields="cases" desc_by="cases" tricker_speed="30"]
              </div>
            </div>
            <?php echo do_shortcode( '[covtags-tricker-world-card inner-spacing="0 0 5 0" fields="cases" desc_by="cases" tricker_speed="30"]' );?>
          </div>

          <div class="row">
            <div class="col-md-6">
              <!-- World Wide -->
              <div class="tags-shortcode-container">
                <div class="widget-title">
                  <h3>World Statistics with custom fields</h3>
                </div>
                <div class="shortcode-container">
                  <div class="shorthandler">
                    <i class="fas fa-copy"></i>
                    Shortcode
                  </div>
                  <div class="short-contents" contentEditable="false">
                    [covtags-statistics title="World Wide" country="" align_text="left" rounded="15" icon_flag="yes" fields="cases,critical,active" layout="flat" style="style-2"]
                  </div>
                </div>
                <?php echo do_shortcode ('[covtags-statistics title="World Wide" rounded="15" align_text="left" country="" icon_flag="yes" fields="cases,critical,active" layout="flat" style="style-2"]'); ?>
              </div>
            </div>


            <div class="col-md-6">
              <!-- World Wide -->
              <div class="tags-shortcode-container">
                <div class="widget-title">
                  <h3>World Statistics with custom fields</h3>
                </div>
                <div class="shortcode-container">
                  <div class="shorthandler">
                    <i class="fas fa-copy"></i>
                    Shortcode
                  </div>
                  <div class="short-contents" contentEditable="false">
                    [covtags-statistics title="russia" rounded="15" align_text="left" country="russia" icon_flag="yes" fields="todayCases,todayDeaths,critical" layout="flat" style="style-3"]
                  </div>
                </div>
                <?php echo do_shortcode ('[covtags-statistics title="russia" rounded="15" align_text="left" country="russia" icon_flag="yes" fields="todayCases,todayDeaths,critical" layout="flat" style="style-3"]'); ?>
              </div>
            </div>
          </div>

          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>World Wide Datatable with custom fields and options</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-all-countries fields="cases,deaths,todayCases,critical,recovered" field_colors="#823471,#ea2028,#9e343f,#f79e20,#1089a7" desc_by="cases" rows_per_page='7' style="style-1" graph_type="line" paging_type="serials" icon_flag="yes"]
              </div>
            </div>
            <?php echo do_shortcode( '[covtags-all-countries fields="cases,deaths,todayCases,critical,recovered" field_colors="#823471,#ea2028,#9e343f,#f79e20,#1089a7" desc_by="cases" rows_per_page=7 style="style-1" graph_type="line" paging_type="serials" icon_flag="yes"]' );?>
          </div>

          <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <!-- Active Cases OR Closed Cases -->
                <div class="tags-shortcode-container">
                  <div class="widget-title">
                    <h3>Country Active Cases</h3>
                  </div>
                  <div class="shortcode-container">
                    <div class="shorthandler">
                      <i class="fas fa-copy"></i>
                      Shortcode
                    </div>
                    <div class="short-contents" contentEditable="false">
                      [covtags-status country="france" status_type="active" use_graph_with="bar" colors="#EA2027,#006266,#9980FA" title="Cases which had an outcome" style="style-1"]
                    </div>
                  </div>
                  <?php echo do_shortcode( '[covtags-status country="france" status_type="active" use_graph_with="bar" colors="#EA2027,#006266,#9980FA" title="Cases which had an outcome" style="style-1"]' );?>
                </div>
              </div>

              <div class="col-md-6 col-sm-6 col-xs-12">
                <!-- Active Cases OR Closed Cases -->
                <div class="tags-shortcode-container">
                  <div class="widget-title">
                    <h3>Country Closed Cases</h3>
                  </div>
                  <div class="shortcode-container">
                    <div class="shorthandler">
                      <i class="fas fa-copy"></i>
                      Shortcode
                    </div>
                    <div class="short-contents" contentEditable="false">
                      [covtags-status country="france" status_type="closed" use_graph_with="line" colors="#EA2027,#006266,#9980FA" title="Currently Infected Patients" style="style-1"]
                    </div>
                  </div>
                  <?php echo do_shortcode( '[covtags-status country="france" status_type="closed" use_graph_with="line" colors="#EA2027,#006266,#9980FA" title="Currently Infected Patients" style="style-1"]' );?>
                </div>
              </div>

          </div>

          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>World Wide Map</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-map]
              </div>
            </div>
            <?php echo do_shortcode( '[covtags-map]' );?>
          </div>

        </div>
      </div>
      <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="covtags-main-container">
          <!-- Active Cases OR Closed Cases -->
          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>Closed Cases Card</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-status status_type="closed" use_graph_with="polarArea" colors="#EA2027,#006266,#9980FA" title="Currently Infected Patients" style="style-1"]
              </div>
            </div>
            <?php echo do_shortcode( '[covtags-status status_type="closed" use_graph_with="polarArea" colors="#EA2027,#006266,#9980FA" title="Currently Infected Patients" style="style-1"]' );?>
          </div>

          <!-- Active Cases OR Closed Cases -->
          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>Active Cases Card</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-status status_type="active" use_graph_with="doughnut" colors="#546de5,#f19066,#58B19F" title="Cases which had an outcome" style="style-1"]
              </div>
            </div>
            <?php echo do_shortcode( '[covtags-status status_type="active" use_graph_with="doughnut" colors="#546de5,#f19066,#58B19F" title="Cases which had an outcome" style="style-1"]' );?>
          </div>

          <!-- World Wide -->
          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>World Statistics with custom fields</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-statistics title="World Wide" country="" icon_flag="yes" fields="cases,critical,active" layout="flat" style="style-1"]
              </div>
            </div>
            <?php echo do_shortcode ('[covtags-statistics title="World Wide" country="" icon_flag="yes" fields="cases,critical,active" layout="flat" style="style-1"]'); ?>
          </div>


          <!-- World Wide -->
          <div class="tags-shortcode-container">
            <div class="widget-title">
              <h3>Country Statistics - table layout</h3>
            </div>
            <div class="shortcode-container">
              <div class="shorthandler">
                <i class="fas fa-copy"></i>
                Shortcode
              </div>
              <div class="short-contents" contentEditable="false">
                [covtags-statistics title="United States " country="usa" icon_flag="yes" fields="cases,deaths,recovered" layout="table" style="style-1"]
              </div>
            </div>
            <?php echo do_shortcode ('[covtags-statistics title="United States " country="usa" icon_flag="yes" fields="cases,deaths,recovered" layout="table" style="style-1"]'); ?>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>



<footer class="container">
    <p>The demo is installed separately. Not included in our plugin.</p>
    <p>
      EraTags@2020
    </p>
</footer>
<?php
  get_footer();
?>

<!-- World Statistics Or Country Statistics
<div class="tags-shortcode-container">
  <?php //echo do_shortcode ('[covtags-statistics title="World Wide" country="" icon_flag="yes" fields="cases,today cases,critical,active" layout="flat" style="style-1"]'); ?>
</div>


 List Of All countries
<div class="tags-shortcode-container">
  <?php //echo do_shortcode( '[covtags-all-countries title="List of All Countries" fields="deaths,cases,recovered" field_colors="red,blue,green" desc_by="deaths" rows_per_page=7 style="style-1" graph_type="line" paging_type="serials" icon_flag="yes"]' );?>
</div>
-->
