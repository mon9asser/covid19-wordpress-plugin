



<div class="container-fluid footer-data text-center">
  <div class="container text-center">
    This Demo is installed separately Not included in the plugin
  </div>
  <div class="container text-center">
    Designed by Eratags. Wordpress Development
  </div>
</div>
  <?php wp_footer(); ?>
  </body>
</html>
